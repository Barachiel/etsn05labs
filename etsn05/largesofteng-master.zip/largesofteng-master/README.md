# largesofteng
Course material for the course "Large-Scale Software Engineering".
